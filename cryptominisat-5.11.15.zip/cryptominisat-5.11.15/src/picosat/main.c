int picosat_main (int, char **);

int
main (int argc, char **argv)
{
  return picosat_main (argc, argv);
}
